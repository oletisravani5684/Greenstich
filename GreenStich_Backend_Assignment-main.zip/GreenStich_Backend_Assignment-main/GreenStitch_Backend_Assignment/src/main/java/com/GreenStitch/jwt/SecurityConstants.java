package com.GreenStitch.jwt;

public interface SecurityConstants {

	public static final String JWT_KEY ="secretshimbhu$77$kumawat~skking99~";
	public static final String JWT_HEADER ="Authorization";
}
